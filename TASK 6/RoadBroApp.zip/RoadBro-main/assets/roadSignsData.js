// roadSignsData.js

import img180DegreeTurn from './roadSigns/180_Degree_Turn.jpg';
import imgCityLimits from './roadSigns/City_Limits.jpg';
import imgConstructionSign from './roadSigns/construction_sign.jpeg';
import imgCrossRoad from './roadSigns/Cross_Road.jpg';
import imgFourWayIntersectionAhead from './roadSigns/Four_Way_Intersection_Ahead.jpg';
import imgHospitalAhead from './roadSigns/Hospital_Ahead.jpg';
import imgJunctionAhead from './roadSigns/Junction_Ahead.jpg';
import imgLeftCurve from './roadSigns/Left_Curve.jpg';
import imgLeftTurn from './roadSigns/Left_Turn.jpg';
import imgNoParking from './roadSigns/no_parking.jpeg';
import imgPedestrianCrossing from './roadSigns/pedestrian_crossing.jpeg';
import imgRightCurveAhead from './roadSigns/Right_Curve_Ahead.jpg';
import imgRightLaneEnds from './roadSigns/Right_Lane_Ends.jpg';
import imgRightTurn from './roadSigns/Right_Turn.jpg';
import imgSeriesOfCurvesAhead from './roadSigns/Series_of_Curves_Ahead.jpg';
import imgSpeedLimit from './roadSigns/speed_limit.jpeg';
import imgStopSign from './roadSigns/Stop_sign.jpg';
import imgTwoWayTrafficAhead from './roadSigns/Two_Way_Traffic_Ahead.jpg';
import imgTwoWayTraffic from './roadSigns/Two_Way_Traffic.jpg';
import imgWindingRoad from './roadSigns/Winding_Road.jpg';
import imgYIntersection from './roadSigns/Y_Intersection.jpg';
import imgYieldSign from './roadSigns/yield_sign.jpg';


const roadSignsData = [
  {
    id: 1,
    name: "180-Degree Turn",
    category: "Danger",
    image: img180DegreeTurn,
  },
  {
    id: 2,
    name: "Left Curve",
    category: "Danger",
    image: imgLeftCurve,
  },
  {
    id: 3,
    name: "Left Turn",
    category: "Danger",
    image: imgLeftTurn,
  },
  {
    id: 4,
    name: "Right Curve Ahead",
    category: "Danger",
    image: imgRightCurveAhead,
  },
  {
    id: 5,
    name: "Right Lane Ends",
    category: "Danger",
    image: imgRightLaneEnds,
  },
  {
    id: 6,
    name: "Right Turn",
    category: "Danger",
    image: imgRightTurn,
  },
  {
    id: 7,
    name: "Series of Curves Ahead",
    category: "Danger",
    image: imgSeriesOfCurvesAhead,
  },
  {
    id: 8,
    name: "Stop Sign",
    category: "Danger",
    image: imgStopSign,
  },
  {
    id: 9,
    name: "Two-Way Traffic Ahead",
    category: "Danger",
    image: imgTwoWayTrafficAhead,
  },
  {
    id: 10,
    name: "Two-Way Traffic",
    category: "Danger",
    image: imgTwoWayTraffic,
  },
  {
    id: 11,
    name: "Winding Road",
    category: "Danger",
    image: imgWindingRoad,
  },
  {
    id: 12,
    name: "Speed Limit",
    category: "Danger",
    image: imgSpeedLimit,
  },
  {
    id: 13,
    name: "Yield Sign",
    category: "Danger",
    image: imgYieldSign,
  },

  {
    id: 14,
    name: "Cross Road",
    category: "Directional",
    image: imgCrossRoad,
  },
  {
    id: 15,
    name: "Four-Way Intersection Ahead",
    category: "Directional",
    image: imgFourWayIntersectionAhead,
  },
  {
    id: 16,
    name: "Junction Ahead",
    category: "Directional",
    image: imgJunctionAhead,
  },
  {
    id: 17,
    name: "Y-Intersection",
    category: "Directional",
    image: imgYIntersection,
  },

  {
    id: 18,
    name: "Hospital Ahead",
    category: "Information",
    image: imgHospitalAhead,
  },
  {
    id: 19,
    name: "No Parking",
    category: "Information",
    image: imgNoParking,
  },
  {
    id: 20,
    name: "Pedestrian Crossing",
    category: "Information",
    image: imgPedestrianCrossing,
  },

  {
    id: 21,
    name: "City Limits",
    category: "Location",
    image: imgCityLimits,
  },
  {
    id: 22,
    name: "Construction Sign",
    category: "Location",
    image: imgConstructionSign,
  },
];

export default roadSignsData;

export const getSignById = (id) => {
  return roadSignsData.find((sign) => sign.id === id);
};

export const getSignsByCategory = (category) => {
  return roadSignsData.filter((sign) => sign.category === category);
};

export const getAllCategories = () => {
  return [...new Set(roadSignsData.map((sign) => sign.category))];
};

export const searchSignsByName = (searchTerm) => {
  return roadSignsData.filter((sign) =>
    sign.name.toLowerCase().includes(searchTerm.toLowerCase())
  );
};

export const getCategoryStats = () => {
  const stats = {};
  roadSignsData.forEach((sign) => {
    stats[sign.category] = (stats[sign.category] || 0) + 1;
  });
  return stats;
};

export const validateImagePaths = () => {
  const missingImages = [];
  roadSignsData.forEach((sign) => {
    if (!sign.image) {
      missingImages.push(`${sign.name} (ID: ${sign.id})`);
    }
  });
  return missingImages;
};