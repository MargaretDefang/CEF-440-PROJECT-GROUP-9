import React, { useEffect, useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, Alert, ScrollView, Image,
} from 'react-native';
import { launchImageLibrary } from 'react-native-image-picker';
import { useTranslation } from 'react-i18next';

// ✅ Correct Firebase import path
import { auth, db } from '../../config/firebaseSetup';

import {
  doc, getDoc, updateDoc, deleteDoc,
} from 'firebase/firestore';
import {
  updateEmail, updatePassword, deleteUser,
} from 'firebase/auth';

// ✨ REMOVED: No need to import defaultProfilePic anymore

const AdminProfileScreen = ({ navigation }) => {
  const { t } = useTranslation();
  const [uid, setUid] = useState(null);
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [profileImage, setProfileImage] = useState(null); // This will be null initially

  const user = auth.currentUser;

  useEffect(() => {
    if (user) {
      setUid(user.uid);
      fetchProfile(user.uid);
    }
  }, [user]);

  const fetchProfile = async (uid) => {
    try {
      const userDocRef = doc(db, 'users', uid);
      const userDocSnap = await getDoc(userDocRef);
      if (userDocSnap.exists()) {
        const data = userDocSnap.data();
        setFirstName(data.firstName || '');
        setLastName(data.lastName || '');
        setEmail(data.email || '');
        setProfileImage(data.profileImage || null);
      }
    } catch (error) {
      console.error('Error fetching profile:', error);
      Alert.alert('Error', 'Failed to load profile data.');
    }
  };

  const handleImagePick = () => {
    launchImageLibrary({ mediaType: 'photo' }, (response) => {
      if (response.assets && response.assets.length > 0) {
        setProfileImage(response.assets[0].uri);
      }
    });
  };

  const handleSave = async () => {
    if (!firstName || !lastName || !email) {
      Alert.alert(t('admin.savedError') || 'Error', t('user.savedError') || 'Please fill all required fields.');
      return;
    }

    try {
      const userDocRef = doc(db, 'users', uid);

      await updateDoc(userDocRef, {
        firstName,
        lastName,
        email,
        profileImage, // This will store null if no image is selected
      });

      if (email !== user.email) {
        await updateEmail(user, email);
      }

      if (password) {
        await updatePassword(user, password);
      }

      Alert.alert(t('admin.savedSuccess') || 'Success', t('user.savedSuccess') || 'Profile updated successfully.');
      setPassword('');
    } catch (error) {
      console.error('Update Error:', error);
      Alert.alert('Update Failed', error.message);
    }
  };

  const handleLogout = async () => {
    try {
      await auth.signOut();
      navigation.replace('AdminLogin');
    } catch (error) {
      Alert.alert('Logout Failed', error.message);
    }
  };

  const handleDeleteAccount = () => {
    Alert.alert(
      'Delete Account',
      'Are you sure you want to delete your admin account? This cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              const userDocRef = doc(db, 'users', uid);
              await deleteDoc(userDocRef);
              await deleteUser(user);
              Alert.alert('Account Deleted', 'Your account has been deleted.');
              navigation.replace('AdminLogin');
            } catch (error) {
              Alert.alert('Delete Failed', error.message);
            }
          },
        },
      ],
    );
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>{t('admin.profile')}</Text>

      <TouchableOpacity onPress={handleImagePick} style={styles.imageWrapper}>
        {/* ✨ THE CHANGE: Conditionally render the Image component */}
        {profileImage ? (
          <Image
            source={{ uri: profileImage }}
            style={styles.profileImage}
          />
        ) : (
          // This View acts as the empty placeholder area
          <View style={[styles.profileImage, styles.emptyProfileImage]} />
        )}
        <Text style={styles.changePhoto}>Change Photo</Text>
      </TouchableOpacity>

      <TextInput
        style={styles.input}
        placeholder={t('user.firstName') || 'First Name'}
        value={firstName}
        onChangeText={setFirstName}
      />

      <TextInput
        style={styles.input}
        placeholder={t('user.lastName') || 'Last Name'}
        value={lastName}
        onChangeText={setLastName}
      />

      <TextInput
        style={styles.input}
        placeholder={t('admin.email') || 'Email'}
        keyboardType="email-address"
        autoCapitalize="none"
        value={email}
        onChangeText={setEmail}
      />

      <View style={styles.passwordContainer}>
        <TextInput
          style={[styles.input, { flex: 1 }]}
          placeholder={t('admin.password') || 'Password'}
          secureTextEntry={!showPassword}
          value={password}
          onChangeText={setPassword}
          autoCapitalize="none"
        />
        <TouchableOpacity onPress={() => setShowPassword(!showPassword)} style={styles.toggleButton}>
          <Text style={{ color: '#007AFF' }}>{showPassword ? 'Hide' : 'Show'}</Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity onPress={handleSave} style={styles.saveButton}>
        <Text style={styles.saveText}>{t('user.saveSettings') || 'Save Settings'}</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={handleLogout} style={styles.logoutButton}>
        <Text style={styles.logoutText}>{t('admin.logout') || 'Logout'}</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={handleDeleteAccount} style={styles.deleteButton}>
        <Text style={styles.deleteText}>Delete Account</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 25,
    paddingVertical: 20,
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    marginBottom: 25,
  },
  imageWrapper: {
    alignItems: 'center',
    marginBottom: 25,
  },
  profileImage: {
    width: 120,
    height: 120,
    borderRadius: 60,
  },
  // ✨ NEW STYLE FOR THE EMPTY IMAGE AREA
  emptyProfileImage: {
    backgroundColor: '#f0f0f0', // A light grey background to make the empty circle visible
    borderWidth: 1,
    borderColor: '#ccc',
    borderStyle: 'dashed', // Optional: visually indicate it's a placeholder for input
  },
  changePhoto: {
    marginTop: 8,
    color: '#2563eb',
    fontWeight: '600',
  },
  input: {
    width: '100%',
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 10,
    paddingHorizontal: 15,
    paddingVertical: 12,
    marginBottom: 18,
    fontSize: 16,
  },
  passwordContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '100%',
    marginBottom: 20,
  },
  toggleButton: {
    paddingHorizontal: 10,
  },
  saveButton: {
    backgroundColor: '#10b981',
    paddingVertical: 14,
    borderRadius: 12,
    width: '100%',
    marginBottom: 15,
    alignItems: 'center',
  },
  saveText: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 18,
  },
  logoutButton: {
    backgroundColor: '#ef4444',
    paddingVertical: 14,
    borderRadius: 12,
    width: '100%',
    marginBottom: 15,
    alignItems: 'center',
  },
  logoutText: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 18,
  },
  deleteButton: {
    backgroundColor: '#b91c1c',
    paddingVertical: 14,
    borderRadius: 12,
    width: '100%',
    marginBottom: 30,
    alignItems: 'center',
  },
  deleteText: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 18,
  },
});

export default AdminProfileScreen;