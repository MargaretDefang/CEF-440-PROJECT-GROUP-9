import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  Button,
  StyleSheet,
  Alert,
  TouchableOpacity,
} from 'react-native';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { auth, db } from '../../../config/firebaseSetup';
import AsyncStorage from '@react-native-async-storage/async-storage';
import CryptoJS from 'crypto-js';

// Hash verification function (must match registration)
const verifyAdminCode = (inputCode, storedHash) => {
  const salt = 'roadwatch-admin-salt-2024'; // Same salt as registration
  const inputHash = CryptoJS.SHA256(inputCode + salt).toString();
  return inputHash === storedHash;
};

export default function AdminLoginScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [adminCode, setAdminCode] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async () => {
    if (!email || !password || !adminCode) {
      Alert.alert('Missing Fields', 'Please fill in all fields.');
      return;
    }

    setIsLoading(true);

    try {
      // First, authenticate with Firebase Auth
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;

      // Get user document from Firestore
      const userDocRef = doc(db, 'users', user.uid);
      const userDoc = await getDoc(userDocRef);

      if (!userDoc.exists()) {
        throw new Error('User profile not found. Please contact support.');
      }

      const userData = userDoc.data();

      // Verify admin role
      if (userData.role !== 'admin') {
        // Sign out the user since they're not an admin
        await auth.signOut();
        throw new Error('Access denied. Admin privileges required.');
      }

      // Verify admin code using hash comparison
      if (!userData.adminCode || !verifyAdminCode(adminCode, userData.adminCode)) {
        // Sign out the user since admin code is wrong
        await auth.signOut();
        throw new Error('Invalid admin code. Please check your credentials.');
      }

      // Cache admin data locally
      try {
        await AsyncStorage.multiSet([
          ['userRole', 'admin'],
          ['userToken', user.uid],
          ['userEmail', user.email || ''],
          ['adminVerified', 'true']
        ]);
      } catch (storageError) {
        console.warn('Failed to cache admin data:', storageError);
      }

      // Update last login timestamp
      try {
        await doc(db, 'users', user.uid).update({
          lastLoginAt: new Date(),
          updatedAt: new Date()
        });
      } catch (updateError) {
        console.warn('Failed to update login timestamp:', updateError);
      }

      Alert.alert(
        'Welcome Back!', 
        `Hello ${userData.firstName}! Admin access granted.`,
        [
          {
            text: 'Continue',
            onPress: () => navigation.replace('Admin')
          }
        ]
      );

    } catch (error) {
      console.error('Login error:', error);
      
      let errorMessage = 'Login failed. Please try again.';
      
      // Handle specific Firebase errors
      if (error.code === 'auth/user-not-found') {
        errorMessage = 'No account found with this email address.';
      } else if (error.code === 'auth/wrong-password') {
        errorMessage = 'Incorrect password. Please try again.';
      } else if (error.code === 'auth/invalid-email') {
        errorMessage = 'Please enter a valid email address.';
      } else if (error.code === 'auth/user-disabled') {
        errorMessage = 'This account has been disabled. Please contact support.';
      } else if (error.code === 'auth/too-many-requests') {
        errorMessage = 'Too many failed login attempts. Please try again later.';
      } else if (error.message) {
        errorMessage = error.message;
      }
      
      Alert.alert('Login Error', errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Admin Login</Text>

      <Text style={styles.label}>Email</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter admin email"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
        autoCapitalize="none"
        editable={!isLoading}
      />

      <Text style={styles.label}>Password</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter password"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
        editable={!isLoading}
      />

      <Text style={styles.label}>Admin Code</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter your admin code"
        value={adminCode}
        onChangeText={setAdminCode}
        secureTextEntry
        editable={!isLoading}
      />

      <View style={styles.buttonContainer}>
        <Button 
          title={isLoading ? "Signing In..." : "Login"} 
          onPress={handleLogin} 
          color="#007AFF"
          disabled={isLoading}
        />
      </View>

      <TouchableOpacity
        style={{ marginTop: 15 }}
        onPress={() => navigation.navigate('AdminRegister')}
        disabled={isLoading}
      >
        <Text style={styles.registerLink}>
          Don't have an admin account? Register
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={{ marginTop: 10 }}
        onPress={() => navigation.navigate('RoleSelection')}
        disabled={isLoading}
      >
        <Text style={styles.backLink}>← Back to Role Selection</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    padding: 20, 
    justifyContent: 'center', 
    backgroundColor: '#fff' 
  },
  title: { 
    fontSize: 24, 
    fontWeight: 'bold', 
    marginBottom: 30, 
    textAlign: 'center',
    color: '#333'
  },
  label: { 
    fontSize: 16, 
    marginBottom: 5,
    fontWeight: '500'
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 6,
    padding: 10,
    marginBottom: 15,
  },
  buttonContainer: { 
    marginTop: 10 
  },
  registerLink: {
    color: '#007AFF',
    textAlign: 'center',
    fontSize: 14,
  },
  backLink: {
    color: '#666',
    textAlign: 'center',
    fontSize: 14,
  },
});