import React, { useEffect } from 'react';
import { View, ActivityIndicator, StyleSheet } from 'react-native';
import { onAuthStateChanged } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { auth, db } from '../../../config/firebaseSetup';

export default function AdminAuthLoadingScreen({ navigation }) {
  useEffect(() => {
    let isMounted = true;

    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        try {
          const docRef = doc(db, 'users', user.uid);
          const docSnap = await getDoc(docRef);

          if (!isMounted) return;

          if (docSnap.exists()) {
            if (docSnap.data().role === 'admin') {
              navigation.replace('AdminMain'); // Your main admin screen navigator
            } else {
              console.warn('User is not an admin');
              navigation.replace('AdminLogin'); // If not an admin
            }
          } else {
            console.warn('User document not found');
            navigation.replace('AdminLogin');
          }
        } catch (error) {
          console.error('Error checking admin role:', error);
          if (isMounted) {
            navigation.replace('AdminLogin');
          }
        }
      } else {
        navigation.replace('AdminLogin'); // If not logged in
      }
    });

    return () => {
      isMounted = false;
      unsubscribe();
    };
  }, [navigation]);

  return (
    <View style={styles.container}>
      <ActivityIndicator size="large" color="#2563eb" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center' },
});
