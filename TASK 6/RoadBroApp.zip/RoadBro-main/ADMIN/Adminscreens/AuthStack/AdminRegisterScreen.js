import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  Button,
  StyleSheet,
  Alert,
  TouchableOpacity,
} from 'react-native';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';
import { auth, db } from '../../../config/firebaseSetup';
import CryptoJS from 'crypto-js';

// Hashing functions
const hashAdminCode = (adminCode) => {
  const salt = 'roadwatch-admin-salt-2024'; // Use a unique salt for your app
  return CryptoJS.SHA256(adminCode + salt).toString();
};

// Default admin notification settings
const defaultAdminNotificationSettings = {
  pushNotifications: true,
  emailNotifications: true,
  roadReports: true,
  roadClosures: true,
  trafficAlerts: true,
  systemUpdates: true,
  maintenanceAlerts: true,
  adminAlerts: true,
  userReports: true,
  emergencyNotifications: true
};

export default function AdminRegisterScreen({ navigation }) {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [adminCode, setAdminCode] = useState('');

  const validateAdminCode = (code) => {
    // Add your admin code validation rules here
    if (code.length < 6) {
      return { valid: false, message: 'Admin code must be at least 6 characters long' };
    }
    if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(code)) {
      return { 
        valid: false, 
        message: 'Admin code must contain at least one uppercase letter, one lowercase letter, and one number' 
      };
    }
    return { valid: true };
  };

  const handleRegister = async () => {
    // Validation checks
    if (!firstName || !lastName || !email || !password || !confirmPassword || !adminCode) {
      Alert.alert('Missing Fields', 'Please fill in all fields.');
      return;
    }

    if (password !== confirmPassword) {
      Alert.alert('Password Mismatch', 'Passwords do not match.');
      return;
    }

    // Validate admin code strength
    const codeValidation = validateAdminCode(adminCode);
    if (!codeValidation.valid) {
      Alert.alert('Invalid Admin Code', codeValidation.message);
      return;
    }

    console.log("auth", auth);
    console.log("db", db);

    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;

      // Hash the admin code before storing
      const hashedAdminCode = hashAdminCode(adminCode);

      // Save admin profile in Firestore with hashed adminCode and structured settings
      await setDoc(doc(db, 'users', user.uid), {
        firstName,
        lastName,
        email,
        role: 'admin',
        adminCode: hashedAdminCode, // Store hashed version
        languagePreference: 'en', // Default language
        profilePictureURL: '',
        notificationSettings: defaultAdminNotificationSettings,
        createdAt: new Date(),
        updatedAt: new Date(),
        isActive: true
      });

      Alert.alert(
        'Success', 
        'Admin registered successfully! Please remember your admin code as it cannot be recovered.',
        [
          {
            text: 'OK',
            onPress: () => navigation.replace('AdminLogin')
          }
        ]
      );

    } catch (e) {
      console.error('Registration error:', e);
      let errorMessage = 'Registration failed. Please try again.';
      
      // Handle specific Firebase errors
      if (e.code === 'auth/email-already-in-use') {
        errorMessage = 'This email is already registered. Please use a different email.';
      } else if (e.code === 'auth/weak-password') {
        errorMessage = 'Password is too weak. Please use a stronger password.';
      } else if (e.code === 'auth/invalid-email') {
        errorMessage = 'Please enter a valid email address.';
      }
      
      Alert.alert('Registration Error', errorMessage);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Admin Registration</Text>

      <Text style={styles.label}>First Name</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter your first name"
        value={firstName}
        onChangeText={setFirstName}
      />

      <Text style={styles.label}>Last Name</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter your last name"
        value={lastName}
        onChangeText={setLastName}
      />

      <Text style={styles.label}>Email</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter admin email"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
        autoCapitalize="none"
      />

      <Text style={styles.label}>Password</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter password (min 6 characters)"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
      />

      <Text style={styles.label}>Confirm Password</Text>
      <TextInput
        style={styles.input}
        placeholder="Re-enter password"
        value={confirmPassword}
        onChangeText={setConfirmPassword}
        secureTextEntry
      />

      <Text style={styles.label}>Admin Code</Text>
      <TextInput
        style={styles.input}
        placeholder="Create secure admin code (min 6 chars, mixed case + number)"
        value={adminCode}
        onChangeText={setAdminCode}
        secureTextEntry
      />
      <Text style={styles.hint}>
        Admin code must contain uppercase, lowercase, and number
      </Text>

      <View style={styles.buttonContainer}>
        <Button title="Register" onPress={handleRegister} color="#007AFF" />
      </View>

      <TouchableOpacity
        style={{ marginTop: 15 }}
        onPress={() => navigation.navigate('AdminLogin')}
      >
        <Text style={styles.loginLink}>Already have an account? Login</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    padding: 20, 
    justifyContent: 'center', 
    backgroundColor: '#fff' 
  },
  title: { 
    fontSize: 24, 
    fontWeight: 'bold', 
    marginBottom: 30, 
    textAlign: 'center' 
  },
  label: { 
    fontSize: 16, 
    marginBottom: 5,
    fontWeight: '500'
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 6,
    padding: 10,
    marginBottom: 15,
  },
  hint: {
    fontSize: 12,
    color: '#666',
    marginTop: -10,
    marginBottom: 15,
    fontStyle: 'italic'
  },
  buttonContainer: { 
    marginTop: 10 
  },
  loginLink: {
    color: '#007AFF',
    textAlign: 'center',
    fontSize: 14,
  },
});