// ADMIN/Adminscreens/ManageUsersScreen.js

import React, { useEffect, useState, useCallback } from 'react'; // Added useCallback
import {
  View,
  Text,
  TextInput,
  FlatList,
  TouchableOpacity,
  Alert,
  StyleSheet,
  ActivityIndicator,
} from 'react-native';
import { collection, getDocs, deleteDoc, doc } from 'firebase/firestore'; // Removed getFirestore, initializeApp

import { db } from '../../config/firebaseSetup'; // Example path: assuming firebaseSetup.js is in 'root/config/'

export default function ManageUsersScreen() {
  const [users, setUsers] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Fetch users from Firestore
  // Using useCallback to memoize the function, preventing unnecessary re-creations
  const fetchUsers = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      // 'db' is now imported from your centralized setup and ready to use
      const usersCol = collection(db, 'users');
      const usersSnapshot = await getDocs(usersCol);
      const usersList = usersSnapshot.docs.map(userDoc => ({ // Renamed 'doc' to 'userDoc' for clarity
        id: userDoc.id,
        ...userDoc.data(),
      }));
      setUsers(usersList);
    } catch (err) {
      setError('Failed to load users.');
      console.error('Error fetching users:', err); // Enhanced error logging
    } finally { // Use finally to ensure loading is set to false regardless of success or error
      setLoading(false);
    }
  }, []); // Empty dependency array means this function is created once

  // Fetch users when the component mounts
  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]); // Depend on fetchUsers to ensure it's called if memoized value changes (though unlikely with empty deps)

  // Handle user deletion
  const handleDelete = useCallback((userId) => {
    Alert.alert(
      'Delete User',
      'Are you sure you want to delete this user permanently?', // Clearer alert message
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              // 'db' is imported and ready
              await deleteDoc(doc(db, 'users', userId));
              setUsers((prevUsers) => prevUsers.filter(user => user.id !== userId)); // Use prevUsers for clarity
              Alert.alert('Success', 'User deleted successfully.'); // Clearer success message
            } catch (err) {
              Alert.alert('Error', `Failed to delete user: ${err.message}`); // More informative error alert
              console.error('Error deleting user:', err); // Enhanced error logging
            }
          },
        },
      ]
    );
  }, []); 


  const filteredUsers = users.filter(user =>
    user.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.email?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Render individual user item in FlatList
  const renderItem = ({ item }) => (
    <View style={styles.userCard}>
      <View style={{ flex: 1 }}>
        <Text style={styles.userName}>{item.name || 'N/A'}</Text> 
        <Text style={styles.userEmail}>{item.email || 'N/A'}</Text> 
        <Text style={styles.userRole}>{item.role || 'N/A'}</Text> 
      </View>
      <TouchableOpacity
        style={styles.deleteButton}
        onPress={() => handleDelete(item.id)}
      >
        <Text style={styles.deleteText}>Delete</Text>
      </TouchableOpacity>
    </View>
  );

  // Conditional rendering for loading state
  if (loading) {
    return (
      <View style={[styles.container, styles.centerContent]}>
        <ActivityIndicator size="large" color="#0066cc" />
        <Text style={styles.loadingText}>Loading users...</Text>
      </View>
    );
  }

  // Conditional rendering for error state
  if (error) {
    return (
      <View style={[styles.container, styles.centerContent]}>
        <Text style={styles.errorText}>{error}</Text>
        <TouchableOpacity onPress={fetchUsers} style={styles.retryButton}>
          <Text style={styles.retryButtonText}>Retry</Text>
        </TouchableOpacity>
      </View>
    );
  }

  // Main component render
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Manage Users</Text>
      <TextInput
        style={styles.searchInput}
        placeholder="Search by name or email"
        value={searchQuery}
        onChangeText={setSearchQuery}
        autoCapitalize="none"
        autoCorrect={false}
      />
      <FlatList
        data={filteredUsers}
        keyExtractor={item => item.id}
        renderItem={renderItem}
        ListEmptyComponent={<Text style={styles.emptyText}>No users found.</Text>}
        contentContainerStyle={styles.flatListContent}
      />
    </View>
  );
}

// --- Styles ---
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f3f4f6',
  },
  centerContent: { // New style for centering loading/error views
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    marginBottom: 20,
    color: '#111827',
  },
  searchInput: {
    backgroundColor: '#fff',
    paddingHorizontal: 15,
    paddingVertical: 10,
    borderRadius: 8,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: '#ccc',
    shadowColor: '#000', // Added shadow for better UI
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  userCard: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    marginBottom: 12,
    elevation: 3, // Increased elevation for more depth
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 3.84,
    alignItems: 'center',
  },
  userName: {
    fontSize: 18, // Slightly larger font
    fontWeight: '600',
    color: '#333',
  },
  userEmail: {
    fontSize: 14,
    color: '#666',
    marginTop: 2,
  },
  userRole: {
    fontSize: 13,
    color: '#888',
    marginTop: 4,
    fontStyle: 'italic',
  },
  deleteButton: {
    paddingVertical: 8, 
    paddingHorizontal: 15,
    backgroundColor: '#ef4444',
    borderRadius: 8, 
    marginLeft: 10, 
  },
  deleteText: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 14,
  },
  emptyText: {
    textAlign: 'center',
    color: '#777',
    marginTop: 30,
    fontSize: 16,
  },
  retryButton: {
    marginTop: 20, // Increased margin
    backgroundColor: '#007bff', // A more common blue
    paddingHorizontal: 25,
    paddingVertical: 12,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 3,
    elevation: 4,
  },
  retryButtonText: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 16,
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#555',
  },
  errorText: {
    color: 'red',
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 10,
  },
  flatListContent: {
    paddingBottom: 20, 
  },
});