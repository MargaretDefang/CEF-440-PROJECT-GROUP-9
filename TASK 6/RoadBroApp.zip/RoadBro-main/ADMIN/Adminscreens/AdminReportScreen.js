import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  Alert,
  StyleSheet,
  Modal,
  TextInput as RNTextInput,
  Image,
} from 'react-native';

import {
  collection,
  onSnapshot,
  doc,
  updateDoc,
  deleteDoc,
} from 'firebase/firestore';

import { db } from '../../config/firebaseSetup'; // adjust path if needed

const AdminReportScreen = () => {
  const [reports, setReports] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState('All');
  const [editModalVisible, setEditModalVisible] = useState(false);
  const [editReport, setEditReport] = useState(null);

  // Fetch reports with real-time updates
  useEffect(() => {
    const reportsCol = collection(db, 'reports');
    const unsubscribe = onSnapshot(
      reportsCol,
      (snapshot) => {
        const fetchedReports = snapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setReports(fetchedReports);
      },
      (error) => {
        console.error('Error fetching reports:', error);
      }
    );

    return () => unsubscribe();
  }, []);

  const handleVerify = async (id) => {
    try {
      const reportRef = doc(db, 'reports', id);
      await updateDoc(reportRef, { verified: true });
      Alert.alert('Verified', 'Report marked as verified.');
    } catch (error) {
      console.error('Verification error:', error);
      Alert.alert('Error', 'Failed to verify report.');
    }
  };

  const handleDelete = (id) => {
    Alert.alert('Delete Report', 'Are you sure?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          try {
            const reportRef = doc(db, 'reports', id);
            await deleteDoc(reportRef);
            Alert.alert('Deleted', 'Report has been deleted.');
          } catch (error) {
            console.error('Delete error:', error);
            Alert.alert('Error', 'Failed to delete report.');
          }
        },
      },
    ]);
  };

  const handleEdit = (report) => {
    setEditReport(report);
    setEditModalVisible(true);
  };

  const saveEdit = async () => {
    try {
      const reportRef = doc(db, 'reports', editReport.id);
      await updateDoc(reportRef, {
        title: editReport.title,
        description: editReport.description,
        location: editReport.location,
      });
      setEditModalVisible(false);
      Alert.alert('Updated', 'Report updated successfully.');
    } catch (error) {
      console.error('Edit error:', error);
      Alert.alert('Error', 'Failed to update report.');
    }
  };

  const filteredReports = reports.filter((r) => {
    const matchesSearch = (r.title + r.location)
      .toLowerCase()
      .includes(searchTerm.toLowerCase());
    const matchesFilter =
      filter === 'All' ||
      (filter === 'Verified' && r.verified) ||
      (filter === 'Unverified' && !r.verified);
    return matchesSearch && matchesFilter;
  });

  const renderItem = ({ item }) => (
    <View style={styles.card}>
      <View style={styles.header}>
        <Text style={styles.title}>{item.title}</Text>
        {item.verified && <Text style={styles.verified}>✔ Verified</Text>}
      </View>
      <Text style={styles.location}>📍 {item.location}</Text>
      <Text style={styles.description}>{item.description}</Text>
      {item.image ? (
        <Image source={{ uri: item.image }} style={styles.image} />
      ) : (
        <Text style={styles.noImage}>No image</Text>
      )}
      <View style={styles.buttonRow}>
        {!item.verified && (
          <TouchableOpacity
            onPress={() => handleVerify(item.id)}
            style={styles.verifyButton}
          >
            <Text style={styles.buttonText}>Verify</Text>
          </TouchableOpacity>
        )}
        <TouchableOpacity onPress={() => handleEdit(item)} style={styles.editButton}>
          <Text style={styles.buttonText}>Edit</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => handleDelete(item.id)} style={styles.deleteButton}>
          <Text style={styles.buttonText}>Delete</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.headerTitle}>Admin Incident Reports</Text>

      <TextInput
        placeholder="Search by title or location..."
        value={searchTerm}
        onChangeText={setSearchTerm}
        style={styles.searchInput}
      />

      <View style={styles.toggleRow}>
        {['All', 'Verified', 'Unverified'].map((item) => (
          <TouchableOpacity
            key={item}
            onPress={() => setFilter(item)}
            style={[styles.toggleButton, filter === item && styles.activeToggle]}
          >
            <Text style={[styles.toggleText, filter === item && styles.activeToggleText]}>
              {item}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <FlatList
        data={filteredReports}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        ListEmptyComponent={<Text style={styles.empty}>No matching reports found.</Text>}
      />

      {/* Edit Modal */}
      <Modal
        visible={editModalVisible}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setEditModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalBox}>
            <Text style={styles.modalTitle}>Edit Report</Text>

            <RNTextInput
              style={styles.modalInput}
              placeholder="Title"
              value={editReport?.title}
              onChangeText={(text) => setEditReport({ ...editReport, title: text })}
            />
            <RNTextInput
              style={styles.modalInput}
              placeholder="Description"
              value={editReport?.description}
              onChangeText={(text) => setEditReport({ ...editReport, description: text })}
            />
            <RNTextInput
              style={styles.modalInput}
              placeholder="Location"
              value={editReport?.location}
              onChangeText={(text) => setEditReport({ ...editReport, location: text })}
            />

            <View style={styles.modalActions}>
              <TouchableOpacity onPress={saveEdit} style={styles.saveButton}>
                <Text style={styles.saveText}>Save</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => setEditModalVisible(false)} style={styles.cancelButton}>
                <Text style={styles.cancelText}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
};

export default AdminReportScreen;

// styles remain unchanged
const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#f9fafb' },
  headerTitle: { fontSize: 22, fontWeight: 'bold', marginBottom: 12, color: '#111' },
  searchInput: {
    backgroundColor: '#fff',
    borderColor: '#d1d5db',
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    marginBottom: 12,
  },
  toggleRow: { flexDirection: 'row', justifyContent: 'space-around', marginBottom: 12 },
  toggleButton: {
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#ccc',
  },
  toggleText: { fontSize: 14, color: '#333' },
  activeToggle: { backgroundColor: '#0066cc' },
  activeToggleText: { color: '#fff' },
  card: {
    backgroundColor: '#fff',
    padding: 14,
    borderRadius: 10,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  header: { flexDirection: 'row', justifyContent: 'space-between' },
  title: { fontSize: 16, fontWeight: 'bold', color: '#111827' },
  verified: { color: 'green', fontWeight: '600' },
  location: { marginTop: 4, color: '#6b7280' },
  description: { marginTop: 6, color: '#374151' },
  noImage: { marginTop: 10, fontStyle: 'italic', color: '#9ca3af' },
  image: {
    marginTop: 10,
    height: 160,
    borderRadius: 10,
    resizeMode: 'cover',
  },
  buttonRow: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 12 },
  verifyButton: {
    backgroundColor: '#22c55e',
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 6,
  },
  editButton: {
    backgroundColor: '#3b82f6',
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 6,
  },
  deleteButton: {
    backgroundColor: '#ef4444',
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 6,
  },
  buttonText: { color: '#fff', fontWeight: 'bold' },
  empty: { textAlign: 'center', marginTop: 30, color: '#6b7280' },

  // Modal Styles
  modalContainer: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalBox: {
    width: '90%',
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 12,
  },
  modalTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 10 },
  modalInput: {
    borderColor: '#d1d5db',
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    marginBottom: 12,
  },
  modalActions: { flexDirection: 'row', justifyContent: 'flex-end' },
  saveButton: {
    backgroundColor: '#0066cc',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 6,
    marginRight: 10,
  },
  saveText: { color: '#fff', fontWeight: 'bold' },
  cancelButton: {
    backgroundColor: '#9ca3af',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 6,
  },
  cancelText: { color: '#fff', fontWeight: 'bold' },
});
