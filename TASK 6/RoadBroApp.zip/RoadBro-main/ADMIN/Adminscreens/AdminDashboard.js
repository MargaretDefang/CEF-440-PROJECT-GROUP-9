// src/ADMIN/Adminscreens/AdminDashboard.js

import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTranslation } from 'react-i18next';

const AdminDashboard = ({ navigation }) => {
  const { t } = useTranslation();

  const handleLogout = () => {
    navigation.replace('AdminLogin');
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>{t('admin.dashboard')}</Text>

      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('ManageUsers')}>
        <Ionicons name="people-outline" size={20} color="#007AFF" />
        <Text style={styles.buttonText}>{t('admin.manageUsers')}</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('AdminReport')}>
        <Ionicons name="document-text-outline" size={20} color="#007AFF" />
        <Text style={styles.buttonText}>{t('admin.reports')}</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('AdminProfile')}>
        <Ionicons name="person-outline" size={20} color="#007AFF" />
        <Text style={styles.buttonText}>{t('admin.profile')}</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('AdminSettings')}>
        <Ionicons name="settings-outline" size={20} color="#007AFF" />
        <Text style={styles.buttonText}>{t('admin.settings')}</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
        <Ionicons name="log-out-outline" size={20} color="#fff" />
        <Text style={styles.logoutText}>{t('admin.logout')}</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

export default AdminDashboard;

const styles = StyleSheet.create({
  container: {
    padding: 20,
    alignItems: 'center',
    backgroundColor: '#f0f4f8',
    flexGrow: 1,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 30,
    color: '#222',
  },
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#e6f0ff',
    padding: 12,
    marginBottom: 15,
    borderRadius: 8,
    width: '100%',
  },
  buttonText: {
    fontSize: 16,
    color: '#007AFF',
    marginLeft: 10,
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#cc0000',
    padding: 12,
    marginTop: 30,
    borderRadius: 8,
    width: '100%',
    justifyContent: 'center',
  },
  logoutText: {
    fontSize: 16,
    color: '#fff',
    marginLeft: 10,
  },
});
