// ADMIN/Admin.js

import React, { useEffect, useState } from 'react';
import { View, ActivityIndicator, StyleSheet } from 'react-native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { onAuthStateChanged } from 'firebase/auth';
import { auth, db } from '../config/firebaseSetup';

// Admin Auth Screens
import AdminLoginScreen from './Adminscreens/AuthStack/AdminLoginScreen';
import AdminRegisterScreen from './Adminscreens/AuthStack/AdminRegisterScreen';

// Admin Core Screens
import AdminDashboard from './Adminscreens/AdminDashboard';
import AdminProfileScreen from './Adminscreens/AdminProfileScreen';
import AdminReportScreen from './Adminscreens/AdminReportScreen';
import ManageUsersScreen from './Adminscreens/ManageUsersScreen';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

// Tab Navigator for Admin Main Screens
function AdminTabNavigator() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: '#2563eb',
        tabBarInactiveTintColor: '#6b7280',
        tabBarStyle: { paddingBottom: 5, height: 60 },
        tabBarIcon: ({ color, focused }) => {
          let iconName;
          switch (route.name) {
            case 'Dashboard':
              iconName = focused ? 'grid' : 'grid-outline';
              break;
            case 'Reports':
              iconName = focused ? 'document-text' : 'document-text-outline';
              break;
            case 'Users':
              iconName = focused ? 'people' : 'people-outline';
              break;
            case 'Profile':
              iconName = focused ? 'person-circle' : 'person-circle-outline';
              break;
            default:
              iconName = 'ellipse';
          }
          return <Ionicons name={iconName} size={22} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Dashboard" component={AdminDashboard} />
      <Tab.Screen name="Reports" component={AdminReportScreen} />
      <Tab.Screen name="Users" component={ManageUsersScreen} />
      <Tab.Screen name="Profile" component={AdminProfileScreen} />
    </Tab.Navigator>
  );
}

// Auth Check Screen (runs only once)
function AdminAuthGate({ navigation }) {
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        const role = await AsyncStorage.getItem('userRole');
        if (role === 'admin') {
          navigation.replace('AdminMain');
        } else {
          await AsyncStorage.clear();
          navigation.replace('AdminLogin');
        }
      } else {
        navigation.replace('AdminLogin');
      }
      setChecking(false);
    });

    return unsubscribe;
  }, [navigation]);

  if (checking) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#2563eb" />
      </View>
    );
  }

  return null;
}

// Main Admin Navigator
export default function Admin() {
  return (
    <Stack.Navigator initialRouteName="AdminAuthGate" screenOptions={{ headerShown: false }}>
      <Stack.Screen name="AdminAuthGate" component={AdminAuthGate} />
      <Stack.Screen name="AdminLogin" component={AdminLoginScreen} />
      <Stack.Screen name="AdminRegister" component={AdminRegisterScreen} />
      <Stack.Screen name="AdminMain" component={AdminTabNavigator} />
    </Stack.Navigator>
  );
}

const styles = StyleSheet.create({
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
});
