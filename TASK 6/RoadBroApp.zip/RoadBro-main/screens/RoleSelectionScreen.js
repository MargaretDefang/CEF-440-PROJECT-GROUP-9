import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

export default function RoleSelectionScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title} accessibilityRole="header" accessibilityLabel="Select your role">
        Select Your Role
      </Text>

      <TouchableOpacity
        activeOpacity={0.7}
        style={[styles.button, { backgroundColor: '#2563eb' }]}
        onPress={() => navigation.replace('AdminLogin')} // Navigate to Admin Login Screen
        accessibilityRole="button"
        accessibilityLabel="Login as Admin"
      >
        <Text style={styles.buttonText}>Admin Login</Text>
      </TouchableOpacity>

      <TouchableOpacity
        activeOpacity={0.7}
        style={[styles.button, { backgroundColor: '#10b981' }]}
        onPress={() => navigation.replace('Login')} // Navigate to User Login Screen
        accessibilityRole="button"
        accessibilityLabel="Login as User"
      >
        <Text style={styles.buttonText}>User Login</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
    paddingHorizontal: 30,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    marginBottom: 40,
    color: '#111',
  },
  button: {
    width: '100%',
    paddingVertical: 15,
    borderRadius: 10,
    marginBottom: 20,
    justifyContent: 'center',
    alignItems: 'center',
    // You could add shadow here for iOS / Android if you want
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '600',
  },
});
