// config/firebaseSetup.js
import { initializeApp, getApps, getApp } from 'firebase/app';
import { initializeAuth, getReactNativePersistence } from 'firebase/auth'; 
import ReactNativeAsyncStorage from '@react-native-async-storage/async-storage'; 
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyDoXGLttrpSxv3I-rDpZIv8qLCbFg6f2Ek",
  authDomain: "roadbro-9f432.firebaseapp.com",
  projectId: "roadbro-9f432",
  storageBucket: "roadbro-9f432.appspot.com",
  messagingSenderId: "553341218433",
  appId: "1:553341218433:web:72a40b6519b1b45a2aa780"
};
let app;
if (!getApps().length) {
  app = initializeApp(firebaseConfig);
  } else {
  app = getApp();
}
export const auth = initializeAuth(app, {
  persistence: getReactNativePersistence(ReactNativeAsyncStorage)
});
export const db = getFirestore(app);
export default app;