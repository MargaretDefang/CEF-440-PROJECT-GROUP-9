import React, { useState, useEffect } from 'react';
import {
  View,
  StyleSheet,
  Alert,
  ActivityIndicator,
  TouchableOpacity,
  Text,
  Switch,
} from 'react-native';
import MapView, { Marker, Callout } from 'react-native-maps';
import * as Location from 'expo-location';
import MapViewDirections from 'react-native-maps-directions';
import NetInfo from '@react-native-community/netinfo';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../../config/firebaseConfig';

const GOOGLE_MAPS_APIKEY = 'AIzaSyDdY5c6W1GmEcqFrJqyAd5kxlCI6UCXeME';

const LATITUDE_DELTA = 0.01;
const LONGITUDE_DELTA = 0.01;

export default function MapScreen() {
  const [region, setRegion] = useState(null);
  const [location, setLocation] = useState(null);
  const [destination, setDestination] = useState(null);

  const [roadSigns, setRoadSigns] = useState([]);
  const [roadStates, setRoadStates] = useState([]);

  const [loading, setLoading] = useState(true);

  const [showSigns, setShowSigns] = useState(true);
  const [showRoadStates, setShowRoadStates] = useState(true);

  const [isConnected, setIsConnected] = useState(true);

  useEffect(() => {
    let subscriber;

    const fetchData = async () => {
      if (!isConnected) {
        Alert.alert(
          'No Internet Connection',
          'You are offline. Showing cached data if available.'
        );

        // Try to load cached data from AsyncStorage
        try {
          const cachedSigns = await AsyncStorage.getItem('roadSigns');
          const cachedStates = await AsyncStorage.getItem('roadStates');

          if (cachedSigns) setRoadSigns(JSON.parse(cachedSigns));
          if (cachedStates) setRoadStates(JSON.parse(cachedStates));
        } catch (e) {
          console.warn('Error loading cached data', e);
        }

        setLoading(false);
        return;
      }

      setLoading(true);
      try {
        const signsSnapshot = await getDocs(collection(db, 'roadSigns'));
        const signs = signsSnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data(),
        }));

        const statesSnapshot = await getDocs(collection(db, 'roadStates'));
        const states = statesSnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data(),
        }));

        setRoadSigns(signs);
        setRoadStates(states);

        // Cache data locally for offline use
        await AsyncStorage.setItem('roadSigns', JSON.stringify(signs));
        await AsyncStorage.setItem('roadStates', JSON.stringify(states));
      } catch (error) {
        Alert.alert('Error', 'Failed to fetch map data.');
        console.error(error);
      } finally {
        setLoading(false);
      }
    };

    const init = async () => {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission Denied', 'Location permission is needed.');
        setLoading(false);
        return;
      }

      const loc = await Location.getCurrentPositionAsync({});
      const { latitude, longitude } = loc.coords;

      setLocation({ latitude, longitude });
      setRegion({
        latitude,
        longitude,
        latitudeDelta: LATITUDE_DELTA,
        longitudeDelta: LONGITUDE_DELTA,
      });

      fetchData();

      subscriber = await Location.watchPositionAsync(
        {
          accuracy: Location.Accuracy.High,
          timeInterval: 5000,
          distanceInterval: 10,
        },
        newLocation => {
          const { latitude, longitude } = newLocation.coords;
          setLocation({ latitude, longitude });
          setRegion({
            latitude,
            longitude,
            latitudeDelta: LATITUDE_DELTA,
            longitudeDelta: LONGITUDE_DELTA,
          });
        }
      );
    };

    init();

    // Subscribe to network status changes
    const unsubscribeNetInfo = NetInfo.addEventListener(state => {
      setIsConnected(state.isConnected);
    });

    return () => {
      subscriber?.remove();
      unsubscribeNetInfo();
    };
  }, [isConnected]);

  if (loading || !region || !location) {
    return (
      <View style={styles.loader}>
        <ActivityIndicator size="large" color="tomato" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Filters */}
      <View style={styles.filterContainer}>
        <View style={styles.filterItem}>
          <Text style={styles.filterLabel}>Show Road Signs</Text>
          <Switch value={showSigns} onValueChange={setShowSigns} />
        </View>
        <View style={styles.filterItem}>
          <Text style={styles.filterLabel}>Show Road States</Text>
          <Switch value={showRoadStates} onValueChange={setShowRoadStates} />
        </View>
      </View>

      {/* Offline banner */}
      {!isConnected && (
        <View style={styles.offlineBanner}>
          <Text style={{ color: 'white' }}>You are offline</Text>
        </View>
      )}

      <MapView
        style={styles.map}
        region={region}
        showsUserLocation
        showsMyLocationButton
      >
        {/* Road signs markers */}
        {showSigns &&
          roadSigns.map(sign => (
            <Marker
              key={sign.id}
              coordinate={sign.coordinate}
              title={sign.name}
              pinColor="blue"
              onPress={() => setDestination(sign.coordinate)}
            >
              <Callout>
                <View style={{ maxWidth: 200 }}>
                  <Text style={{ fontWeight: 'bold' }}>{sign.name}</Text>
                  <Text>Category: {sign.category}</Text>
                </View>
              </Callout>
            </Marker>
          ))}

        {/* Road state markers */}
        {showRoadStates &&
          roadStates.map(state => (
            <Marker
              key={state.id}
              coordinate={state.coordinate}
              title={state.title}
              pinColor={state.state === 'bad' ? 'red' : 'green'}
              onPress={() => setDestination(state.coordinate)}
            >
              <Callout>
                <View style={{ maxWidth: 200 }}>
                  <Text style={{ fontWeight: 'bold' }}>{state.title}</Text>
                  <Text>{state.description}</Text>
                  <Text>Status: {state.state}</Text>
                </View>
              </Callout>
            </Marker>
          ))}

        {/* Route directions */}
        {destination && isConnected && (
          <MapViewDirections
            origin={location}
            destination={destination}
            apikey={GOOGLE_MAPS_APIKEY}
            strokeWidth={4}
            strokeColor="blue"
            optimizeWaypoints={true}
            onError={err => console.warn('Route error:', err)}
          />
        )}
      </MapView>

      {/* Clear Route Button */}
      {destination && (
        <TouchableOpacity
          style={styles.clearButton}
          onPress={() => setDestination(null)}
          accessibilityLabel="Clear route"
        >
          <Text style={styles.clearButtonText}>Clear Route</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  map: { flex: 1 },
  loader: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  clearButton: {
    position: 'absolute',
    bottom: 30,
    left: 20,
    backgroundColor: 'rgba(255,255,255,0.9)',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 20,
    elevation: 3,
  },
  clearButtonText: {
    color: '#007AFF',
    fontWeight: '600',
    fontSize: 16,
  },
  filterContainer: {
    position: 'absolute',
    top: 10,
    left: 10,
    right: 10,
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: 'rgba(255,255,255,0.95)',
    borderRadius: 8,
    paddingVertical: 8,
    zIndex: 10,
    elevation: 10,
  },
  filterItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  filterLabel: {
    marginRight: 8,
    fontWeight: '600',
  },
  offlineBanner: {
    position: 'absolute',
    top: 70,
    left: 10,
    right: 10,
    backgroundColor: 'red',
    paddingVertical: 6,
    borderRadius: 6,
    zIndex: 20,
    alignItems: 'center',
  },
});
