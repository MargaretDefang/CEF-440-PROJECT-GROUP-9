import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Image,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../../config/firebaseConfig';
import roadSignsData from '../../assets/roadSignsData';

// Import the logo image at the top level
import appLogo from '../../assets/logo.png';

const categories = ['order', 'danger', 'info', 'location', 'directional'];

const categoryLabels = {
  order: 'Order Signs',
  danger: 'Danger Signs',
  info: 'Information Signs',
  location: 'Location Signs',
  directional: 'Directional Signs',
};

export default function HomeScreen() {
  const [expanded, setExpanded] = useState({
    directional: false,
    order: false,
    danger: false,
    info: false,
    location: false,
  });

  const [signs, setSigns] = useState([]);
  const [loading, setLoading] = useState(false);

  const toggleSection = (key) => {
    setExpanded((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  useEffect(() => {
    const fetchSigns = async () => {
      setLoading(true);
      try {
        const querySnapshot = await getDocs(collection(db, 'roadSigns'));
        const firebaseSigns = [];
        querySnapshot.forEach((doc) => {
          firebaseSigns.push({ id: doc.id, ...doc.data() });
        });

        if (firebaseSigns.length > 0) {
          setSigns(firebaseSigns);
        } else {
          throw new Error('No signs found in Firestore. Falling back to local data.');
        }
      } catch (error) {
        console.warn('Error fetching from Firestore:', error.message);
        Alert.alert('Offline Mode', 'Using local road signs data.');
        setSigns(roadSignsData);
      } finally {
        setLoading(false);
      }
    };

    fetchSigns();
  }, []);

  const signsByCategory = (category) => signs.filter((s) =>
    s.category.toLowerCase() === category.toLowerCase()
  );

  const renderDropdown = (label, key) => {
    const icon = {
      order: 'ellipse-outline',
      danger: 'warning-outline',
      info: 'information-circle-outline',
      location: 'location-outline',
      directional: 'navigate-outline',
    };

    return (
      <TouchableOpacity
        style={styles.dropdown}
        onPress={() => toggleSection(key)}
        accessibilityLabel={`Toggle ${label} section`}
      >
        <Text style={styles.dropdownText}>{label}</Text>
        <Ionicons name={icon[key]} size={20} color="#666" />
      </TouchableOpacity>
    );
  };

  const renderSignsGrid = (category) => {
    const filtered = signsByCategory(category);
    if (filtered.length === 0) {
      return <Text style={{ padding: 10, fontStyle: 'italic' }}>No signs available</Text>;
    }

    return (
      <View style={styles.signGrid}>
        {filtered.map(({ id, imageURL, image, name }) => (
          <View key={id} style={styles.signItem}>
            <Image
              source={imageURL ? { uri: imageURL } : image}
              style={styles.signIcon}
            />
            <Text style={styles.signLabel}>{name}</Text>
          </View>
        ))}
      </View>
    );
  };

  if (loading) {
    return (
      <View style={[styles.container, { justifyContent: 'center' }]}>
        <ActivityIndicator size="large" color="#2563eb" />
      </View>
    );
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.header}>
        {/* Use the imported appLogo variable */}
        <Image source={appLogo} style={styles.logo} />
        <Text style={styles.title}>RoadBro</Text>
      </View>

      {categories.map((category) => (
        <View key={category}>
          {renderDropdown(categoryLabels[category], category)}
          {expanded[category] && renderSignsGrid(category)}
        </View>
      ))}

      <TouchableOpacity style={styles.fab} onPress={() => alert('Add sign feature coming soon')}>
        <Ionicons name="add" size={28} color="#fff" />
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 16,
    paddingBottom: 100,
    backgroundColor: '#fff',
  },
  header: {
    alignItems: 'center',
    marginBottom: 24,
  },
  logo: {
    width: 50,
    height: 50,
    resizeMode: 'contain',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: 8,
    color: '#007AFF',
  },
  dropdown: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 14,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    marginBottom: 12,
    backgroundColor: '#f0f4f8',
  },
  dropdownText: {
    fontSize: 16,
    fontWeight: '500',
  },
  signGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    marginBottom: 20,
  },
  signItem: {
    margin: 6,
    width: 70,
    alignItems: 'center',
  },
  signIcon: {
    width: 50,
    height: 50,
    resizeMode: 'contain',
  },
  signLabel: {
    marginTop: 4,
    fontSize: 12,
    textAlign: 'center',
  },
  fab: {
    position: 'absolute',
    right: 24,
    bottom: 24,
    backgroundColor: '#007AFF',
    borderRadius: 30,
    width: 60,
    height: 60,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 5,
  },
});