import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Button,
  Alert,
  ActivityIndicator,
  TouchableOpacity,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useTranslation } from 'react-i18next';

const LANGUAGES = [
  { code: 'en', labelKey: 'english' },
  { code: 'fr', labelKey: 'french' },
];

export default function SettingsScreen() {
  const { t, i18n } = useTranslation();

  const [loading, setLoading] = useState(true);
  const [language, setLanguage] = useState(i18n.language || 'en');
  const [voiceAlerts, setVoiceAlerts] = useState(false);
  const [notifications, setNotifications] = useState(true);

  const [originalSettings, setOriginalSettings] = useState({});

  const navigateToNotifications = () => {
    navigation.navigate('NotificationSettings');
  };


  useEffect(() => {
    async function loadSettings() {
      try {
        const lang = await AsyncStorage.getItem('user_language');
        const voice = await AsyncStorage.getItem('user_voiceAlerts');
        const notif = await AsyncStorage.getItem('user_notifications');

        const loadedLanguage = lang || (i18n.language || 'en');
        setLanguage(loadedLanguage);
        i18n.changeLanguage(loadedLanguage);

        setVoiceAlerts(voice === 'true');
        setNotifications(notif === 'true');

        setOriginalSettings({
          language: loadedLanguage,
          voiceAlerts: voice === 'true',
          notifications: notif === 'true',
        });
      } catch (error) {
        console.error('Failed to load settings', error);
        Alert.alert(t('savedError'));
      } finally {
        setLoading(false);
      }
    }
    loadSettings();
  }, []);

  // Auto save language immediately on change
  const onLanguageChange = async (code) => {
    setLanguage(code);
    try {
      await AsyncStorage.setItem('user_language', code);
      i18n.changeLanguage(code);
      setOriginalSettings((prev) => ({ ...prev, language: code }));
    } catch (error) {
      Alert.alert(t('savedError'));
    }
  };

  // Check if settings changed to enable/disable Save button
  const hasChanges =
    language !== originalSettings.language ||
    voiceAlerts !== originalSettings.voiceAlerts ||
    notifications !== originalSettings.notifications;

  const saveSettings = async () => {
    try {
      await AsyncStorage.setItem('user_voiceAlerts', voiceAlerts.toString());
      await AsyncStorage.setItem('user_notifications', notifications.toString());
      setOriginalSettings({
        language,
        voiceAlerts,
        notifications,
      });
      Alert.alert(t('savedSuccess'));
    } catch (error) {
      console.error('Failed to save settings', error);
      Alert.alert(t('savedError'));
    }
  };

  if (loading) {
    return (
      <View style={[styles.container, styles.center]}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{t('settings')}</Text>

      <Text style={styles.sectionTitle}>{t('language')}:</Text>
      {LANGUAGES.map(({ code, labelKey }) => (
        <TouchableOpacity
          key={code}
          style={styles.languageOption}
          onPress={() => onLanguageChange(code)}
          accessibilityRole="radio"
          accessibilityState={{ selected: language === code }}
        >
          <View style={[styles.radioCircle, language === code && styles.selectedRadio]} />
          <Text style={styles.languageLabel}>{t(labelKey)}</Text>
        </TouchableOpacity>
      ))}

      <View style={styles.row}>
        <Text>{t('voiceAlerts')}</Text>
        <Switch value={voiceAlerts} onValueChange={setVoiceAlerts} />
      </View>

      <View style={styles.row}>
        <Text>{t('notifications')}</Text>
        <Switch value={notifications} onValueChange={setNotifications} />
      </View>

      <Button
        title={t('saveSettings')}
        onPress={saveSettings}
        disabled={!hasChanges}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: 'white' },
  center: { justifyContent: 'center', alignItems: 'center' },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 15 },
  sectionTitle: { fontWeight: '600', marginTop: 10, marginBottom: 5 },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginVertical: 10,
  },
  languageOption: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  radioCircle: {
    height: 20,
    width: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: '#777',
    marginRight: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  selectedRadio: {
    backgroundColor: '#4caf50',
    borderColor: '#4caf50',
  },
  languageLabel: {
    fontSize: 16,
  },
});
