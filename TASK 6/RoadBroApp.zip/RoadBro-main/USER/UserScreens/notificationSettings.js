// USER/UserScreens/notificationSettings.js
import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  Switch, 
  StyleSheet, 
  Alert, 
  ScrollView,
  TouchableOpacity,
  ActivityIndicator 
} from 'react-native';
import { onAuthStateChanged } from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { auth, db } from '../../config/firebaseSetup';

// Default notification settings structure
const defaultNotificationSettings = {
  // Push notifications
  pushNotifications: true,
  
  // Email notifications
  emailNotifications: false,
  
  // Road-related notifications
  roadReports: true,
  roadClosures: true,
  trafficAlerts: true,
  
  // System notifications
  systemUpdates: true,
  maintenanceAlerts: false,
  
  // Admin-specific (only for admin users)
  adminAlerts: false,
  userReports: false,
  emergencyNotifications: false
};

// Function to update notification settings
const updateNotificationSettings = async (userId, newSettings) => {
  try {
    const updateData = {
      notificationSettings: newSettings,
      updatedAt: new Date()
    };
    
    const userDocRef = doc(db, 'users', userId);
    await setDoc(userDocRef, updateData, { merge: true });
    
    return { success: true };
    
  } catch (error) {
    console.error('Error updating notification settings:', error);
    return { success: false, error: error.message };
  }
};

const NotificationSettingsScreen = ({ navigation }) => {
  const [settings, setSettings] = useState(defaultNotificationSettings);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [userRole, setUserRole] = useState(null);
  
  // Load user's current notification settings
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        setCurrentUser(user);
        await loadUserData(user.uid);
      } else {
        // User not authenticated, navigate back
        navigation.goBack();
      }
    });

    return unsubscribe;
  }, [navigation]);

  const loadUserData = async (userId) => {
    try {
      // Get user role from AsyncStorage
      const role = await AsyncStorage.getItem('userRole');
      setUserRole(role);

      // Get user document from Firestore
      const userDocRef = doc(db, 'users', userId);
      const userDoc = await getDoc(userDocRef);
      
      if (userDoc.exists()) {
        const userData = userDoc.data();
        if (userData.notificationSettings) {
          setSettings(userData.notificationSettings);
        } else {
          // If no notification settings exist, create default ones
          let defaultSettings = { ...defaultNotificationSettings };
          
          if (role === 'admin') {
            defaultSettings = {
              ...defaultSettings,
              adminAlerts: true,
              userReports: true,
              emergencyNotifications: true,
              emailNotifications: true
            };
          }
          
          setSettings(defaultSettings);
          // Save default settings to database
          await updateNotificationSettings(userId, defaultSettings);
        }
      }
    } catch (error) {
      console.error('Error loading user data:', error);
      Alert.alert('Error', 'Failed to load settings');
    } finally {
      setLoading(false);
    }
  };
  
  const toggleSetting = (key) => {
    setSettings(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };
  
  const saveSettings = async () => {
    if (!currentUser) {
      Alert.alert('Error', 'User not authenticated');
      return;
    }
    
    setSaving(true);
    
    try {
      const result = await updateNotificationSettings(currentUser.uid, settings);
      if (result.success) {
        Alert.alert('Success', 'Notification settings updated!', [
          { text: 'OK', onPress: () => navigation.goBack() }
        ]);
      } else {
        Alert.alert('Error', 'Failed to update settings');
      }
    } catch (error) {
      Alert.alert('Error', 'An unexpected error occurred');
    } finally {
      setSaving(false);
    }
  };

  const renderSettingItem = (key, label, description) => (
    <View style={styles.settingItem} key={key}>
      <View style={styles.settingInfo}>
        <Text style={styles.settingLabel}>{label}</Text>
        {description && <Text style={styles.settingDescription}>{description}</Text>}
      </View>
      <Switch
        value={settings[key]}
        onValueChange={() => toggleSetting(key)}
        trackColor={{ false: '#767577', true: '#10b981' }}
        thumbColor={settings[key] ? '#ffffff' : '#f4f3f4'}
      />
    </View>
  );
  
  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#10b981" />
        <Text style={styles.loadingText}>Loading settings...</Text>
      </View>
    );
  }
  
  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Notification Settings</Text>
        <Text style={styles.headerSubtitle}>Manage how you receive notifications</Text>
      </View>

      {/* General Notifications */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>General</Text>
        {renderSettingItem('pushNotifications', 'Push Notifications', 'Receive push notifications on your device')}
        {renderSettingItem('emailNotifications', 'Email Notifications', 'Receive notifications via email')}
      </View>

      {/* Road Notifications */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Road & Traffic</Text>
        {renderSettingItem('roadReports', 'Road Reports', 'Get notified about new road reports')}
        {renderSettingItem('roadClosures', 'Road Closures', 'Alerts for road closures')}
        {renderSettingItem('trafficAlerts', 'Traffic Alerts', 'Real-time traffic updates')}
      </View>

      {/* System Notifications */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>System</Text>
        {renderSettingItem('systemUpdates', 'System Updates', 'App updates and announcements')}
        {renderSettingItem('maintenanceAlerts', 'Maintenance Alerts', 'Scheduled maintenance notifications')}
      </View>

      {/* Admin Notifications - Only show for admin users */}
      {userRole === 'admin' && (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Admin</Text>
          {renderSettingItem('adminAlerts', 'Admin Alerts', 'Administrative notifications')}
          {renderSettingItem('userReports', 'User Reports', 'Notifications about user-submitted reports')}
          {renderSettingItem('emergencyNotifications', 'Emergency Notifications', 'Critical system alerts')}
        </View>
      )}

      <TouchableOpacity 
        style={[styles.saveButton, saving && styles.saveButtonDisabled]} 
        onPress={saveSettings}
        disabled={saving}
      >
        {saving ? (
          <ActivityIndicator size="small" color="white" />
        ) : (
          <Text style={styles.saveButtonText}>Save Settings</Text>
        )}
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8f9fa',
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#666',
  },
  header: {
    padding: 20,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#e9ecef',
    marginBottom: 10,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#212529',
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#6c757d',
    marginTop: 4,
  },
  section: {
    backgroundColor: 'white',
    marginBottom: 10,
    paddingVertical: 10,
    borderRadius: 8,
    marginHorizontal: 10,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#495057',
    paddingHorizontal: 20,
    paddingBottom: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#f8f9fa',
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#f8f9fa',
  },
  settingInfo: {
    flex: 1,
    marginRight: 15,
  },
  settingLabel: {
    fontSize: 16,
    fontWeight: '500',
    color: '#212529',
  },
  settingDescription: {
    fontSize: 14,
    color: '#6c757d',
    marginTop: 2,
  },
  saveButton: {
    backgroundColor: '#10b981',
    margin: 20,
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  saveButtonDisabled: {
    backgroundColor: '#9ca3af',
  },
  saveButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
});

export default NotificationSettingsScreen;