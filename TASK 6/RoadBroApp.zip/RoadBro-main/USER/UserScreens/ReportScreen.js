import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  Button,
  StyleSheet,
  Alert,
  ScrollView,
  Image,
  Platform,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system';

import { db, storage } from '../../config/firebaseSetup'; // adjust path accordingly
import {
  collection,
  addDoc,
  serverTimestamp,
} from 'firebase/firestore';
import {
  ref,
  uploadBytes,
  getDownloadURL,
} from 'firebase/storage';

export default function ReportScreen() {
  const [location, setLocation] = useState('');
  const [issueType, setIssueType] = useState('');
  const [description, setDescription] = useState('');
  const [image, setImage] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    (async () => {
      if (Platform.OS !== 'web') {
        const { status: cameraStatus } = await ImagePicker.requestCameraPermissionsAsync();
        const { status: mediaStatus } = await ImagePicker.requestMediaLibraryPermissionsAsync();
        if (cameraStatus !== 'granted' || mediaStatus !== 'granted') {
          Alert.alert(
            'Permissions needed',
            'Camera and media library permissions are required to add photos.'
          );
        }
      }
    })();
  }, []);

  const uploadImageAsync = async (uri) => {
    // Convert local URI to blob for Firebase upload
    const blob = await new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.onload = function () {
        resolve(xhr.response);
      };
      xhr.onerror = function (e) {
        console.log(e);
        reject(new TypeError('Network request failed'));
      };
      xhr.responseType = 'blob';
      xhr.open('GET', uri, true);
      xhr.send(null);
    });

    // Create a unique filename
    const filename = `reports/${Date.now()}.jpg`;

    const storageRef = ref(storage, filename);

    // Upload the blob
    await uploadBytes(storageRef, blob);

    // We're done with the blob, close it
    blob.close();

    // Get downloadable URL
    const downloadURL = await getDownloadURL(storageRef);
    return downloadURL;
  };

  const handleSubmit = async () => {
    if (!location.trim() || !issueType.trim() || !description.trim()) {
      Alert.alert('Missing Info', 'Please fill in all fields.');
      return;
    }

    setIsSubmitting(true);

    try {
      let imageUrl = null;
      if (image) {
        imageUrl = await uploadImageAsync(image);
      }

      const reportData = {
        location: location.trim(),
        issueType: issueType.trim(),
        description: description.trim(),
        imageUrl,
        createdAt: serverTimestamp(),
      };

      // Save report to Firestore
      await addDoc(collection(db, 'roadReports'), reportData);

      Alert.alert('✅ Report Sent', 'Thank you for reporting!');

      // Clear form
      setLocation('');
      setIssueType('');
      setDescription('');
      setImage(null);
    } catch (error) {
      console.error('Error submitting report:', error);
      Alert.alert('Error', 'Failed to send report. Please try again.');
    }

    setIsSubmitting(false);
  };

  const pickImage = async () => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 1,
      });

      if (!result.canceled) {
        setImage(result.assets[0].uri);
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to pick image.');
    }
  };

  const takePhoto = async () => {
    try {
      const result = await ImagePicker.launchCameraAsync({
        allowsEditing: true,
        aspect: [4, 3],
        quality: 1,
      });

      if (!result.canceled) {
        setImage(result.assets[0].uri);
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to take photo.');
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
      <Text style={styles.title}>📝 Report a Road Issue</Text>

      <TextInput
        style={styles.input}
        placeholder="Location (e.g. Douala - Bonamoussadi)"
        value={location}
        onChangeText={setLocation}
        returnKeyType="next"
      />

      <TextInput
        style={styles.input}
        placeholder="Issue Type (e.g. Pothole, Flood, Accident)"
        value={issueType}
        onChangeText={setIssueType}
        returnKeyType="next"
      />

      <TextInput
        style={[styles.input, styles.textArea]}
        placeholder="Description (e.g. Huge pothole causing traffic...)"
        value={description}
        onChangeText={setDescription}
        multiline
        numberOfLines={6}
        textAlignVertical="top"
      />

      {image && (
        <Image source={{ uri: image }} style={styles.imagePreview} />
      )}

      <View style={styles.buttonGroup}>
        <Button title="📸 Take Photo" onPress={takePhoto} />
        <View style={{ height: 10 }} />
        <Button title="🖼️ Choose from Gallery" onPress={pickImage} />
      </View>

      <View style={styles.buttonContainer}>
        <Button
          title={isSubmitting ? 'Submitting...' : 'Submit Report'}
          onPress={handleSubmit}
          disabled={isSubmitting}
          color="#007AFF"
        />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    flexGrow: 1,
    justifyContent: 'center',
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    color: '#333',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    padding: 12,
    marginBottom: 15,
    fontSize: 16,
    backgroundColor: '#fafafa',
  },
  textArea: {
    height: 120,
  },
  buttonGroup: {
    marginBottom: 20,
  },
  imagePreview: {
    width: '100%',
    height: 200,
    marginBottom: 15,
    borderRadius: 10,
    borderColor: '#ccc',
    borderWidth: 1,
    resizeMode: 'cover',
  },
  buttonContainer: {
    marginTop: 10,
  },
});
