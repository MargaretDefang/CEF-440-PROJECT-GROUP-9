import React, { useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  AccessibilityInfo,
  ActivityIndicator,
  useColorScheme,
} from 'react-native';

export default function AdminWelcomeBackScreen({ route, navigation }) {
  const adminName = route?.params?.adminName || 'Admin';
  const isDark = useColorScheme() === 'dark';

  useEffect(() => {
    // Accessibility announcement
    AccessibilityInfo.announceForAccessibility(`Welcome back, ${adminName}`);

    // Navigate after short delay
    const timer = setTimeout(() => {
      navigation.replace('Admin'); // ✅ FIXED: Changed from 'AdminDashboard' to 'Admin'
    }, 2000);

    return () => clearTimeout(timer);
  }, [navigation, adminName]);

  return (
    <View style={[styles.container, { backgroundColor: isDark ? '#000' : '#fff' }]}>
      <Text
        style={[styles.text, { color: isDark ? '#fff' : '#111' }]}
        accessibilityRole="header"
      >
        Welcome back, {adminName} 👋
      </Text>
      <ActivityIndicator
        size="large"
        color={isDark ? '#fff' : '#0066cc'}
        style={{ marginTop: 20 }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  text: {
    fontSize: 24,
    fontWeight: 'bold',
  },
});