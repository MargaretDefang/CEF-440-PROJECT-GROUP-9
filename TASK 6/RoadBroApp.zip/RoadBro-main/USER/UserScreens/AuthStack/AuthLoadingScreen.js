import React, { useEffect } from 'react';
import { View, ActivityIndicator, StyleSheet } from 'react-native';
import { auth, db } from '../../../config/firebaseSetup';
import { doc, getDoc } from 'firebase/firestore';

export default function AuthLoadingScreen({ navigation }) {
  useEffect(() => {
    let isMounted = true;

    const checkLoginStatus = async () => {
      try {
        const currentUser = auth.currentUser;

        if (currentUser) {
          const userDocRef = doc(db, 'users', currentUser.uid);
          const userDoc = await getDoc(userDocRef);

          if (!isMounted) return;

          if (!userDoc.exists()) {
            console.warn('User document not found, redirecting to Login.');
            navigation.replace('Login');
            return;
          }

          const userData = userDoc.data();

          if (userData.role === 'admin') {
            navigation.replace('AdminMain'); // Verify this route name
          } else if (userData.role === 'user') {
            navigation.replace('UserMain');  // Verify this route name
          } else {
            console.warn('Unknown role:', userData.role, 'Redirecting to Login.');
            navigation.replace('Login');
          }
        } else {
          navigation.replace('Login');
        }
      } catch (error) {
        console.error('Auth check error:', error);
        if (isMounted) {
          navigation.replace('Login');
        }
      }
    };

    checkLoginStatus();

    return () => {
      isMounted = false;
    };
  }, [navigation]);

  return (
    <View style={styles.container}>
      <ActivityIndicator size="large" color="#2563eb" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
});
