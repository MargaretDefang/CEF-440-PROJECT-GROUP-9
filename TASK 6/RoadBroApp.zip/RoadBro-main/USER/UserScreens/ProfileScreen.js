import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  Button,
  StyleSheet,
  Alert,
  Image,
  TouchableOpacity,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as ImagePicker from 'expo-image-picker';

export default function ProfileScreen({ navigation }) {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [passwordConfirm, setPasswordConfirm] = useState('');
  const [profilePic, setProfilePic] = useState(null);

  useEffect(() => {
    // Load saved profile data from AsyncStorage on mount
    const loadProfile = async () => {
      try {
        const savedFirstName = await AsyncStorage.getItem('firstName');
        const savedLastName = await AsyncStorage.getItem('lastName');
        const savedEmail = await AsyncStorage.getItem('email');
        const savedPic = await AsyncStorage.getItem('profilePic');

        if (savedFirstName) setFirstName(savedFirstName);
        if (savedLastName) setLastName(savedLastName);
        if (savedEmail) setEmail(savedEmail);
        if (savedPic) setProfilePic(savedPic);
      } catch (e) {
        console.log('Failed to load profile', e);
      }
    };
    loadProfile();
  }, []);

  const pickImage = async () => {
    try {
      const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permissionResult.granted) {
        Alert.alert('Permission Denied', 'Permission to access gallery is required!');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        quality: 0.7,
        allowsEditing: true,
        aspect: [1, 1],
      });

      if (!result.canceled) {
        setProfilePic(result.assets[0].uri);
      }
    } catch (error) {
      Alert.alert('Error', 'Could not pick image.');
    }
  };

  const saveProfile = async () => {
    // Trim inputs to avoid accidental spaces
    const trimmedFirstName = firstName.trim();
    const trimmedLastName = lastName.trim();
    const trimmedEmail = email.trim();

    if (!trimmedFirstName || !trimmedLastName || !trimmedEmail) {
      Alert.alert('Validation Error', 'Please fill in all required fields.');
      return;
    }
    if (password !== passwordConfirm) {
      Alert.alert('Validation Error', 'Passwords do not match.');
      return;
    }

    try {
      await AsyncStorage.setItem('firstName', trimmedFirstName);
      await AsyncStorage.setItem('lastName', trimmedLastName);
      await AsyncStorage.setItem('email', trimmedEmail);

      if (profilePic) {
        await AsyncStorage.setItem('profilePic', profilePic);
      }

      if (password) {
        // WARNING: Storing passwords like this is insecure for production apps
        await AsyncStorage.setItem('password', password);
      }

      Alert.alert('Success', 'Profile saved successfully.');
    } catch (e) {
      Alert.alert('Error', 'Failed to save profile.');
    }
  };

  const logout = async () => {
    try {
      await AsyncStorage.removeItem('userToken');
      await AsyncStorage.removeItem('userRole');
      // Replace or fallback to 'Login' or appropriate route in your navigation
      navigation.getParent()?.replace('RoleSelection') || navigation.reset({ index: 0, routes: [{ name: 'RoleSelection' }] });
    } catch (e) {
      console.error('Logout failed:', e);
      Alert.alert('Error', 'Logout failed. Please try again.');
    }
  };

  // Disable save button if required fields empty
  const isSaveDisabled = !firstName.trim() || !lastName.trim() || !email.trim();

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      style={{ flex: 1 }}
    >
      <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
        <Text style={styles.title}>Profile</Text>

        <TouchableOpacity onPress={pickImage} style={styles.imageContainer} accessibilityLabel="Select profile picture">
          {profilePic ? (
            <Image source={{ uri: profilePic }} style={styles.profileImage} />
          ) : (
            <View style={styles.placeholder}>
              <Text style={{ color: '#888', textAlign: 'center' }}>Tap to select profile picture</Text>
            </View>
          )}
        </TouchableOpacity>

        <Text>First Name:</Text>
        <TextInput
          style={styles.input}
          value={firstName}
          onChangeText={setFirstName}
          placeholder="Enter your first name"
          autoCapitalize="words"
          returnKeyType="next"
        />

        <Text>Last Name:</Text>
        <TextInput
          style={styles.input}
          value={lastName}
          onChangeText={setLastName}
          placeholder="Enter your last name"
          autoCapitalize="words"
          returnKeyType="next"
        />

        <Text>Email:</Text>
        <TextInput
          style={styles.input}
          value={email}
          onChangeText={setEmail}
          placeholder="Enter your email"
          keyboardType="email-address"
          autoCapitalize="none"
          returnKeyType="next"
        />

        <Text>Password:</Text>
        <TextInput
          style={styles.input}
          value={password}
          onChangeText={setPassword}
          placeholder="Enter new password"
          secureTextEntry
          returnKeyType="next"
          autoCapitalize="none"
        />

        <Text>Confirm Password:</Text>
        <TextInput
          style={styles.input}
          value={passwordConfirm}
          onChangeText={setPasswordConfirm}
          placeholder="Confirm new password"
          secureTextEntry
          returnKeyType="done"
          autoCapitalize="none"
        />

        <View style={{ marginVertical: 10 }}>
          <Button title="Save Profile" onPress={saveProfile} disabled={isSaveDisabled} />
        </View>

        <View style={{ marginTop: 20 }}>
          <Button
            title="Go to Settings"
            onPress={() =>
              navigation.navigate('SettingsScreen', {
                firstName: firstName.trim(),
                email: email.trim(),
              })
            }
            color="#007AFF"
          />
        </View>

        <View style={{ marginTop: 30 }}>
          <Button title="Logout" onPress={logout} color="#d9534f" />
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: 'white',
    flexGrow: 1,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 15,
    alignSelf: 'center',
  },
  input: {
    borderColor: '#ccc',
    borderWidth: 1,
    padding: 10,
    marginVertical: 8,
    borderRadius: 5,
  },
  imageContainer: {
    alignSelf: 'center',
    marginBottom: 20,
    width: 120,
    height: 120,
    borderRadius: 60,
    overflow: 'hidden',
    backgroundColor: '#eee',
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileImage: {
    width: 120,
    height: 120,
    borderRadius: 60,
  },
  placeholder: {
    justifyContent: 'center',
    alignItems: 'center',
    flex: 1,
  },
});
