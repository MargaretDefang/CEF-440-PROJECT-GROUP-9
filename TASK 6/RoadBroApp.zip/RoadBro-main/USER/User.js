// USER/User.js

import React, { useEffect, useState } from 'react';
import { View, ActivityIndicator, StyleSheet } from 'react-native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { onAuthStateChanged } from 'firebase/auth';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { auth, db } from '../config/firebaseSetup';
import { doc, setDoc, getDoc } from 'firebase/firestore';

import HomeScreen from './UserScreens/HomeScreen';
import MapScreen from './UserScreens/MapScreen';
import ProfileScreen from './UserScreens/ProfileScreen';
import ReportScreen from './UserScreens/ReportScreen';
import SettingsScreen from './UserScreens/SettingsScreen';
import LoginScreen from './UserScreens/AuthStack/LoginScreen'; 
import NotificationSettingsScreen from './UserScreens/notificationSettings';
import WelcomeBackScreen from './UserScreens/WelcomeBackScreen';

const Stack = createNativeStackNavigator();

// Default notification settings structure
export const defaultNotificationSettings = {
  // Push notifications
  pushNotifications: true,
  
  // Email notifications
  emailNotifications: false,
  
  // Road-related notifications
  roadReports: true,
  roadClosures: true,
  trafficAlerts: true,
  
  // System notifications
  systemUpdates: true,
  maintenanceAlerts: false,
  
  // Admin-specific (only for admin users)
  adminAlerts: false,
  userReports: false,
  emergencyNotifications: false
};

// Function to create user with proper notification settings
export const createUserWithNotifications = async (userAuth, userData, role) => {
  try {
    // Base notification settings
    let notificationSettings = {
      ...defaultNotificationSettings
    };
    
    // Add admin-specific settings if admin
    if (role === 'admin') {
      notificationSettings = {
        ...notificationSettings,
        adminAlerts: true,
        userReports: true,
        emergencyNotifications: true,
        emailNotifications: true // Admins get email by default
      };
    }

    const userDocData = {
      email: userAuth.email,
      firstName: userData.firstName || '',
      lastName: userData.lastName || '',
      languagePreference: userData.languagePreference || 'en',
      profilePictureURL: '',
      role: role,
      notificationSettings: notificationSettings,
      createdAt: new Date(),
      updatedAt: new Date(),
      isActive: true
    };

    // Add hashed admin code only for admins
    if (role === 'admin' && userData.adminCode) {
      // You'll need to implement hashAdminCode function
      userDocData.adminCode = userData.adminCode; // Replace with hashed version
    }

    await setDoc(doc(db, 'users', userAuth.uid), userDocData);
    
    return { success: true, userData: userDocData };
    
  } catch (error) {
    console.error('Error creating user:', error);
    return { success: false, error: error.message };
  }
};

// Function to update notification settings
export const updateNotificationSettings = async (userId, newSettings) => {
  try {
    const updateData = {
      notificationSettings: newSettings,
      updatedAt: new Date()
    };
    
    const userDocRef = doc(db, 'users', userId);
    await setDoc(userDocRef, updateData, { merge: true });
    
    return { success: true };
    
  } catch (error) {
    console.error('Error updating notification settings:', error);
    return { success: false, error: error.message };
  }
};

// Function to ensure user has notification settings
export const ensureNotificationSettings = async (userId, userRole) => {
  try {
    const userDocRef = doc(db, 'users', userId);
    const userDoc = await getDoc(userDocRef);
    
    if (userDoc.exists()) {
      const userData = userDoc.data();
      
      // Check if notification settings exist
      if (!userData.notificationSettings) {
        let notificationSettings = { ...defaultNotificationSettings };
        
        // Add admin-specific settings if admin
        if (userRole === 'admin') {
          notificationSettings = {
            ...notificationSettings,
            adminAlerts: true,
            userReports: true,
            emergencyNotifications: true,
            emailNotifications: true
          };
        }
        
        // Update user document with notification settings
        await setDoc(userDocRef, {
          notificationSettings: notificationSettings,
          updatedAt: new Date()
        }, { merge: true });
        
        console.log('Notification settings added to existing user');
      }
    }
  } catch (error) {
    console.error('Error ensuring notification settings:', error);
  }
};

// Auth Check Component
function UserAuthGate({ navigation }) {
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        try {
          const role = await AsyncStorage.getItem('userRole');
          
          if (role === 'user') {
            // Ensure user has notification settings
            await ensureNotificationSettings(user.uid, role);
            navigation.replace('UserMain');
          } else {
            await AsyncStorage.clear();
            navigation.replace('Login');
          }
        } catch (error) {
          console.error('Error in auth check:', error);
          navigation.replace('Login');
        }
      } else {
        navigation.replace('Login');
      }
      setChecking(false);
    });

    return unsubscribe;
  }, [navigation]);

  if (checking) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#10b981" />
      </View>
    );
  }

  return null;
}

// Main User Screens Navigator
function UserMainNavigator() {
  return (
    <Stack.Navigator 
      screenOptions={{ 
        headerShown: false,
        animation: 'slide_from_right',
        animationDuration: 300
      }}
    >
      <Stack.Screen name="Home" component={HomeScreen} />
      <Stack.Screen name="Map" component={MapScreen} />
      <Stack.Screen name="Profile" component={ProfileScreen} />
      <Stack.Screen name="Report" component={ReportScreen} />
      <Stack.Screen name="Settings" component={SettingsScreen} />
      <Stack.Screen 
        name="NotificationSettings" 
        component={NotificationSettingsScreen}
        options={{
          headerShown: true,
          title: 'Notification Settings',
          headerStyle: {
            backgroundColor: '#10b981',
          },
          headerTintColor: '#fff',
          headerTitleStyle: {
            fontWeight: 'bold',
          },
        }}
      />
      <Stack.Screen 
        name="WelcomeBack" 
        component={WelcomeBackScreen}
        options={{
          gestureEnabled: false, // Prevent swipe back
        }}
      />
    </Stack.Navigator>
  );
}

// Main User Stack with Auth Gate
export default function User() {
  return (
    <Stack.Navigator 
      screenOptions={{ 
        headerShown: false,
        animation: 'fade',
        animationDuration: 200
      }} 
      initialRouteName="UserAuthGate"
    >
      <Stack.Screen name="UserAuthGate" component={UserAuthGate} />
      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen name="UserMain" component={UserMainNavigator} />
    </Stack.Navigator>
  );
}

const styles = StyleSheet.create({
  loadingContainer: { 
    flex: 1, 
    justifyContent: 'center', 
    alignItems: 'center',
    backgroundColor: '#f8f9fa'
  },
});