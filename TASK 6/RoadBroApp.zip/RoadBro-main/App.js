import './config/firebaseSetup'
import React, { useEffect, useState } from 'react';
import { View, ActivityIndicator, Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { SafeAreaProvider } from 'react-native-safe-area-context';

// Screens and Navigators
import Admin from './ADMIN/Admin';
import User from './USER/User';
import SplashScreen from './screens/SplashScreen';
import RoleSelectionScreen from './screens/RoleSelectionScreen';
import LoginScreen from './USER/UserScreens/AuthStack/LoginScreen';
import AdminLoginScreen from './ADMIN/Adminscreens/AuthStack/AdminLoginScreen';
import AdminRegisterScreen from './ADMIN/Adminscreens/AuthStack/AdminRegisterScreen';
import RegisterScreen from './USER/UserScreens/AuthStack/RegisterScreen';
import WelcomeBackScreen from './USER/UserScreens/WelcomeBackScreen';
import AdminWelcomeBackScreen from './ADMIN/Adminscreens/AdminWelcomeBackScreen';

// Firebase v9+ imports - FIXED
import { onAuthStateChanged } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { auth, db } from './config/firebaseSetup';

// i18n
import './i18n';

const RootStack = createNativeStackNavigator();

function AuthLoadingRouterScreen({ navigation }) {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    console.log("✅ AuthLoadingRouterScreen mounted");
    let isMounted = true;

    // ✅ FIXED: Use onAuthStateChanged from firebase/auth with correct syntax
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      console.log("📡 onAuthStateChanged triggered:", user);
      if (!isMounted) return;

      try {
        if (user) {
          // ✅ FIXED: Use Firebase v9+ syntax for Firestore
          const userDocRef = doc(db, 'users', user.uid);
          const userDoc = await getDoc(userDocRef);

          if (!isMounted) return;

          // ✅ FIXED: Use exists() method correctly
          if (userDoc.exists()) {
            const { role } = userDoc.data();

            if (!role || !['admin', 'user'].includes(role)) {
              console.warn('Invalid or missing role for user:', user.uid);
              navigation.replace('RoleSelection');
              return;
            }

            try {
              await AsyncStorage.multiSet([
                ['userRole', role],
                ['userToken', user.uid],
                ['userEmail', user.email || ''],
              ]);
            } catch (storageError) {
              console.warn('Failed to cache user data:', storageError);
            }

            navigation.replace(role === 'admin' ? 'AdminWelcomeBack' : 'WelcomeBack');

          } else {
            console.log('User document not found, redirecting to role selection');
            navigation.replace('RoleSelection');
          }
        } else {
          try {
            await AsyncStorage.multiRemove(['userRole', 'userToken', 'userEmail']);
          } catch (storageError) {
            console.warn('Failed to clear cached user data:', storageError);
          }

          navigation.replace('RoleSelection');
        }
      } catch (error) {
        console.error('Error in auth state change handler:', error);

        if (isMounted) {
          Alert.alert(
            'Connection Error',
            'Unable to verify your account. Please check your internet connection and try again.',
            [
              {
                text: 'Retry',
                onPress: () => navigation.replace('AuthLoadingRouter'),
              },
              {
                text: 'Continue Offline',
                onPress: () => navigation.replace('RoleSelection'),
              },
            ]
          );
        }
      } finally {
        if (isMounted) setIsLoading(false);
      }
    });

    return () => {
      isMounted = false;
      unsubscribe();
    };
  }, [navigation]);

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <ActivityIndicator size="large" color="#2563eb" />
    </View>
  );
}

export default function App() {
  return (
    <SafeAreaProvider>
      <NavigationContainer>
        <RootStack.Navigator
          initialRouteName="Splash"
          screenOptions={{ headerShown: false }}
        >
          <RootStack.Screen name="Splash" component={SplashScreen} />
          <RootStack.Screen name="AuthLoadingRouter" component={AuthLoadingRouterScreen} />
          <RootStack.Screen name="RoleSelection" component={RoleSelectionScreen} />
          <RootStack.Screen name="WelcomeBack" component={WelcomeBackScreen} />
          <RootStack.Screen name="AdminWelcomeBack" component={AdminWelcomeBackScreen} />
          <RootStack.Screen name="Login" component={LoginScreen} />
          <RootStack.Screen name="AdminLogin" component={AdminLoginScreen} />
          <RootStack.Screen name="AdminRegister" component={AdminRegisterScreen} />
          <RootStack.Screen name="Register" component={RegisterScreen} />
          <RootStack.Screen name="Admin" component={Admin} />
          <RootStack.Screen name="User" component={User} />
        </RootStack.Navigator>
      </NavigationContainer>
    </SafeAreaProvider>
  );
}