import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import * as RNLocalize from 'react-native-localize';

import en from './locales/en.json';
import fr from './locales/fr.json';

// Safe function to get device language
const getDeviceLanguage = () => {
  try {
    // Use findBestLanguageTag instead of findBestAvailableLanguage
    const bestLanguage = RNLocalize.findBestLanguageTag(['en', 'fr']);
    return bestLanguage ? bestLanguage.languageTag : 'en';
  } catch (error) {
    console.warn('Error detecting device language:', error);
    return 'en'; // fallback to English
  }
};

i18n
  .use(initReactI18next)
  .init({
    compatibilityJSON: 'v3',
    lng: getDeviceLanguage(),
    fallbackLng: 'en',
    resources: {
      en: { translation: en },
      fr: { translation: fr },
    },
    interpolation: {
      escapeValue: false, // React already safes from xss
    },
    react: {
      useSuspense: false, // Important for React Native
    },
    debug: __DEV__, // Enable debug in development
  })
  .catch((error) => {
    console.warn('i18n initialization failed:', error);
  });

export default i18n;